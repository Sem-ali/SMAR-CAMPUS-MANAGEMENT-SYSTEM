<?php
session_start();
if (!isset($_SESSION['person_id'])) {
    header('Location: ../login.php');
    exit();
}
require_once '../includes/db_connect.php';

$person_id = $_SESSION['person_id'];

$sql = "SELECT m.message_id, m.subject, m.sent_datetime, m.read_status,
               CONCAT(s.first_name, ' ', s.last_name) AS sender_name,
               CONCAT(r.first_name, ' ', r.last_name) AS receiver_name,
               m.request_id
        FROM message m
        JOIN person s ON m.sender_person_id = s.person_id
        JOIN person r ON m.receiver_person_id = r.person_id
        WHERE m.sender_person_id = ? OR m.receiver_person_id = ?
        ORDER BY m.sent_datetime DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $person_id, $person_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/index.css">
    <title><?=$lang['messages'] ?></title>
</head>
<body>
    <div class="container">
        <p style="text-align:right;">
        <a href="../switch_lang.php?lang=en">English</a> |
        <a href="../switch_lang.php?lang=tr">Türkçe</a>
        </p>
        <h2><?= $lang['messages'] ?></h2>
        <p><a href="send_message.php"><?= $lang['send_message'] ?></a></p>
        <table border="1">
            <tr>
                <th><?= $lang['subject'] ?></th>
                <th><?= $lang['from'] ?></th>
                <th><?= $lang['to'] ?></th>
                <th><?= $lang['date'] ?></th>
                <th><?= $lang['status'] ?></th>
                <th><?= $lang['request'] ?></th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['subject']) ?></td>
                    <td><?= htmlspecialchars($row['sender_name']) ?></td>
                    <td><?= htmlspecialchars($row['receiver_name']) ?></td>
                    <td><?= $row['sent_datetime'] ?></td>
                    <td><?= $row['read_status'] ?></td>
                    <td><a href="search_request.php?id=<?= $row['request_id'] 
                            ?>"><?= $lang['view'] ?></a></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
                 