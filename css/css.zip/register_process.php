<?php
include "..includes/db.php";

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

// PHP validation
if (empty($name) || empty($email) || empty($password)) {
    die("All fields are required.");
}

// Secure password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert into DB
$sql = "INSERT INTO users (name, email, password) 
        VALUES ('$name', '$email', '$hashed_password')";

if (mysqli_query($conn, $sql)) {
    echo "Registration successful!";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
