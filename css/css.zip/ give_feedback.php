<?php
session_start();
if (!isset($_SESSION['person_id'])) {
    header('Location: ../login.php');
    exit();
}
require_once '../includes/db_connect.php';
if (!isset($_SESSION['lang'])) $_SESSION['lang'] = 'en';
require_once "../includes/lang_{$_SESSION['lang']}.php";

$person_id = $_SESSION['person_id'];

$sql = "SELECT request_id, title FROM request
        WHERE (requester_person_id = ? OR assignee_person_id = ?)
          AND status IN ('Resolved','Closed')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $person_id, $person_id);
$stmt->execute();
$requests = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/index.css">
    <title><?= $lang['give_feedback'] ?></title>
</head>
<body>
    <div class="container">
        <p style="text-align:right;">
            <a href="../switch_lang.php?lang=en">English</a> | 
            <a href="../switch_lang.php?lang=tr">Türkçe</a>
        </p>
        <h2><?= $lang['give_feedback'] ?></h2>
        <form action="Proces/feedback_process.php" method="POST">
            <label><?= $lang['request'] ?>:</label>
            <select name="request_id" required>
                <option value=""><?= $lang['choose_resolved_request'] ?></option>
                <?php foreach ($requests as $req): ?>
                    <option value="<?= $req['request_id'] ?>"><?= htmlspecialchars($req['title']) ?></option>
                <?php endforeach; ?>
            </select><br><br>

            <label><?= $lang['rating'] ?> (1-5):</label>
            <input type="number" name="rating" min="1" max="5" required><br><br>

            <label><?= $lang['comments'] ?>:</label>
            <textarea name="comments" required></textarea><br><br>

            <button type="submit"><?= $lang['submit_feedback'] ?></button>
        </form>
    </div>
</body>
</html>
            