<?php
session_start();
include "../includes/db.php";

// Protect page
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch all requests
$sql = "SELECT d.id, d.title, d.status, d.created_at, u.name 
        FROM demande d
        JOIN utilisateur u ON d.user_id = u.id";

$stid = oci_parse($conn, $sql);
oci_execute($stid);
?>


<?php

/* Total Requests */
$total_sql = "SELECT COUNT(*) AS total FROM demande";
$total_stid = oci_parse($conn, $total_sql);
oci_execute($total_stid);
$total_row = oci_fetch_assoc($total_stid);

/* Pending Requests */
$pending_sql = "SELECT COUNT(*) AS pending 
                FROM demande 
                WHERE status = 'pending'";

$pending_stid = oci_parse($conn, $pending_sql);
oci_execute($pending_stid);
$pending_row = oci_fetch_assoc($pending_stid);

/* Resolved Requests */
$resolved_sql = "SELECT COUNT(*) AS resolved
                 FROM demande
                 WHERE status = 'resolved'";

$resolved_stid = oci_parse($conn, $resolved_sql);
oci_execute($resolved_stid);
$resolved_row = oci_fetch_assoc($resolved_stid);
?>


<h2>Admin Dashboard</h2>
<a href="logout.php">Logout</a>

<div class="navbar">
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="logout.php">Logout</a>
</div>


<h3>All Requests</h3>

<?php
while ($row = oci_fetch_assoc($stid)) {
    echo "<p>";
    echo "ID: " . $row['ID'] . "<br>";
    echo "User: " . $row['NAME'] . "<br>";
    echo "Title: " . $row['TITLE'] . "<br>";
    echo "Status: " . $row['STATUS'] . "<br>";

    // Form to update status
    echo "<form action='update_status.php' method='POST'>";
    echo "<input type='hidden' name='id' value='".$row['ID']."'>";
    echo "<select name='status'>
            <option value='pending'>pending</option>
            <option value='in_progress'>in_progress</option>
            <option value='resolved'>resolved</option>
          </select>";
    echo "<button type='submit'>Update</button>";
    echo "</form>";

    echo "</p><hr>";
}
?>
