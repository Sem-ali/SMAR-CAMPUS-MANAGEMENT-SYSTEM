<?php
include "../includes/db.php";

$keyword = $_GET['keyword'];

$sql = "SELECT d.id, d.title, d.status, u.name
        FROM demande d
        JOIN utilisateur u ON d.user_id = u.id
        WHERE LOWER(d.title) LIKE LOWER(:keyword)";

$stid = oci_parse($conn, $sql);

$searchTerm = "%" . $keyword . "%";

oci_bind_by_name($stid, ":keyword", $searchTerm);

oci_execute($stid);

while ($row = oci_fetch_assoc($stid)) {

    echo "<p>";
    echo "ID: " . $row['ID'] . "<br>";
    echo "Student: " . $row['NAME'] . "<br>";
    echo "Title: " . $row['TITLE'] . "<br>";
    echo "Status: " . $row['STATUS'];
    echo "</p><hr>";
}
?>
