<?php
session_start();
if (!isset($_SESSION['person_id'])) {
    header('Location: ../login.php');
    exit();
}
require_once '../includes/db_connect.php';
if (!isset($_SESSION['lang'])) $_SESSION['lang'] = 'en';
require_once "../includes/lang_{$_SESSION['lang']}.php";

$person_id = $_SESSION['person_id'];

// Feedback given
$sql1 = "SELECT f.feedback_id, f.rating, f.comments, f.submitted_date,
               r.title AS request_title, r.request_id
        FROM feedback f
        JOIN request r ON f.request_id = r.request_id
        WHERE f.author_person_id = ?
        ORDER BY f.submitted_date DESC";
$stmt1 = $conn->prepare($sql1);
$stmt1->bind_param("i", $person_id);
$stmt1->execute();
$given = $stmt1->get_result();

// Feedback received
$sql2 = "SELECT f.feedback_id, f.rating, f.comments, f.submitted_date,
               CONCAT(p.first_name, ' ', p.last_name) AS author_name
        FROM feedback f
        JOIN request r ON f.request_id = r.request_id
        JOIN person p ON f.author_person_id = p.person_id
        WHERE r.requester_person_id = ?
        ORDER BY f.submitted_date DESC";
$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("i", $person_id);
$stmt2->execute();
$received = $stmt2->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/index.css">
    <title><?= $lang['feedback'] ?></title>
</head>
<body>
    <div class="container">
        <p style="text-align:right;">
            <a href="../switch_lang.php?lang=en">English</a> | 
            <a href="../switch_lang.php?lang=tr">Türkçe</a>
        </p>
        <h2><?= $lang['feedback'] ?></h2>

        <h3><?= $lang['feedback_given'] ?></h3>
        <table border="1">
            <tr><th><?= $lang['request'] ?></th><th><?= $lang['rating'] ?></th><th><?= $lang['comments'] ?>
            </th><th><?= $lang['submitted_date'] ?></th></tr>
            <?php while ($row = $given->fetch_assoc()): ?>
                <tr>
                    <td><a href="search_request.php?id=<?= $row['request_id'] ?>">
                    <?= htmlspecialchars($row['request_title']) ?></a></td>
                    <td><?= $row['rating'] ?>/5</td>
                    <td><?= htmlspecialchars($row['comments']) ?></td>
                    <td><?= $row['submitted_date'] ?></td>
                </tr>
            <?php endwhile; ?>
        </table>

        <h3><?= $lang['feedback_received'] ?></h3>
        <table border="1">
            <tr><th><?= $lang['from'] ?></th><th><?= $lang['rating'] ?></th><th>
                    <?= $lang['comments'] ?></th><th>
                    <?= $lang['submitted_date'] ?></th></tr>
            <?php while ($row = $received->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['author_name']) ?></td>
                    <td><?= $row['rating'] ?>/5</td>
                    <td><?= htmlspecialchars($row['comments']) ?></td>
                    <td><?= $row['submitted_date'] ?></td>
                </tr>
            <?php endwhile; ?>
        </table>

        <p><a href="give_feedback.php"><?= $lang['give_feedback'] ?></a></p>
    </div>
</body>
</html>
                