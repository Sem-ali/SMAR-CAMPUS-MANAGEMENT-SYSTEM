<?php
session_start();
include "../includes/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'staff') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM demande WHERE assigned_to = :user_id";
$stid = oci_parse($conn, $sql);

oci_bind_by_name($stid, ":user_id", $user_id);
oci_execute($stid);
?>

<h2>Staff Dashboard</h2>
<a href="logout.php">Logout</a>

<h3>My Assigned Requests</h3>

<?php
while ($row = oci_fetch_assoc($stid)) {
    echo "<p>";
    echo "Title: " . $row['TITLE'] . "<br>";
    echo "Status: " . $row['STATUS'] . "<br>";

    echo "<form action='update_status.php' method='POST'>";
    echo "<input type='hidden' name='id' value='".$row['ID']."'>";
    echo "<select name='status'>
            <option value='pending'>pending</option>
            <option value='in_progress'>in_progress</option>
            <option value='resolved'>resolved</option>
          </select>";
    echo "<button type='submit'>Update</button>";
    echo "</form>";

    echo "</p><hr>";
}
?>
