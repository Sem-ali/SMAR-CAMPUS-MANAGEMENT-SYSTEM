<?php
session_start();
?>

<h2>Create Request</h2>
<!-- It should be add Above the requests list -->
<h3>Search Requests</h3>
<input type="text" id="search" placeholder="Search by title...">
<div id="result"></div>

<form action="create_request_process.php" method="POST">
    Title: <input type="text" name="title" required><br><br>
    Description: <textarea name="description" required></textarea><br><br>
    
    <button type="submit">Submit</button>
</form>

<a href="student_dashboard.php">Back</a>
