<?php
session_start();
include "../includes/db.php";

$user_id = $_SESSION['user_id'];
$title = $_POST['title'];
$description = $_POST['description'];

$sql = "INSERT INTO demande (user_id, title, description) 
        VALUES (:user_id, :title, :description)";
 //----       
$title = trim($_POST['title']);
$description = trim($_POST['description']);
//---
$stid = oci_parse($conn, $sql);

oci_bind_by_name($stid, ":user_id", $user_id);
oci_bind_by_name($stid, ":title", $title);
oci_bind_by_name($stid, ":description", $description);

if (oci_execute($stid)) {
    header("Location: student_dashboard.php");
} else {
    echo "Error!";
}
?>
