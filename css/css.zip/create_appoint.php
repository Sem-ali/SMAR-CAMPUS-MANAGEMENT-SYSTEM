<?php
session_start();
?>

<h2>Book Appointment</h2>

<form action="create_appointment_process.php" method="POST">

    Date:
    <input type="date" name="appointment_date" required><br><br>

    Time:
    <input type="time" name="appointment_time" required><br><br>

    <button type="submit">Book</button>

</form>

<a href="student_dashboard.php">Back</a>
