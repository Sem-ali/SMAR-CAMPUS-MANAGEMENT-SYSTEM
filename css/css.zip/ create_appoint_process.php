<?php
session_start();
include "../includes/db.php";

$user_id = $_SESSION['user_id'];
$date = $_POST['appointment_date'];
$time = $_POST['appointment_time'];

$sql = "INSERT INTO rendezvous 
(user_id, appointment_date, appointment_time)
VALUES (:user_id, TO_DATE(:appointment_date, 'YYYY-MM-DD'), :appointment_time)";

$stid = oci_parse($conn, $sql);

oci_bind_by_name($stid, ":user_id", $user_id);
oci_bind_by_name($stid, ":appointment_date", $date);
oci_bind_by_name($stid, ":appointment_time", $time);

if (oci_execute($stid)) {
    header("Location: student_dashboard.php");
} else {
    echo "Appointment error!";
}
?>
