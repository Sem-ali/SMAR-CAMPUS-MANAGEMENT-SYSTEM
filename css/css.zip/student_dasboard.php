<?php
session_start();
include "../includes/db.php";

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM demande WHERE user_id = :user_id";
$stid = oci_parse($conn, $sql);
oci_bind_by_name($stid, ":user_id", $user_id);
oci_execute($stid);
?>

<h2>Welcome <?php echo $_SESSION['name']; ?></h2>

<a href="create_request.php">Create Request</a>
<a href="logout.php">Logout</a>
<a href="create_appointment.php">Book Appointment</a>

<h3>My Requests</h3>

<?php
while ($row = oci_fetch_assoc($stid)) {
    echo "<p>";
    echo "Title: " . $row['TITLE'] . "<br>";
    echo "Status: " . $row['STATUS'] . "<br>";
    echo "Date: " . $row['CREATED_AT'] . "<br>";
    echo "</p><hr>";
}
?>


<?php 
echo "<h3>Notifications</h3>";

$notif_sql = "SELECT * FROM notification
              WHERE user_id = :user_id
              ORDER BY created_at DESC";

$notif_stid = oci_parse($conn, $notif_sql);

oci_bind_by_name($notif_stid, ":user_id", $user_id);

oci_execute($notif_stid);

while ($notif = oci_fetch_assoc($notif_stid)) {

    echo "<div class='card'>";
    echo $notif['MESSAGE'] . "<br>";
    echo $notif['CREATED_AT'];
    echo "</div>";
}
?>


<?php 
echo "<h3>My Appointments</h3>";
$app_sql = "SELECT * FROM rendezvous WHERE user_id = :user_id";
$app_stid = oci_parse($conn, $app_sql);
oci_bind_by_name($app_stid, ":user_id", $user_id);
oci_execute($app_stid);
while ($app = oci_fetch_assoc($app_stid)) {
    echo "<p>";
    echo "Date: " . $app['APPOINTMENT_DATE'] . "<br>";
    echo "Time: " . $app['APPOINTMENT_TIME'] . "<br>";
    echo "Status: " . $app['STATUS'];
    echo "</p><hr>";
}
?>

<!-- it seems like it has to be an HTML and not a php -->
<div class="navbar">
  <a href="student_dashboard.php">Dashboard</a>
    <a href="create_request.php">Requests</a>
    <a href="create_appointment.php">Appointments</a>
    <a href="logout.php">Logout</a>
</div>
