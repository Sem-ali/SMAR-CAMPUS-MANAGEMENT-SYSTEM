<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="../css/index.css">
    <script src="../js/validate.js"></script>
</head>
<body>

<h2>Register</h2>

<form action="register_process.php" method="POST"> <!--</form> onsubmit ="return validateForm()"> -->
    Name: <input type="text" name="name" id="name"><br><br>
    Email: <input type="email" name="email" id="email"><br><br>
    Password: <input type="password" name="password" id="password"><br><br>
    
    <button type="submit">Register</button>
</form>

</body>
</html>
