<?php
include "..includes/db.php";

$email = $_POST['email'];
$password = $_POST['password'];

// Prepare query
$sql = "SELECT * FROM utilisateur WHERE email = :email";

$stid = oci_parse($conn, $sql);
oci_bind_by_name($stid, ":email", $email);
oci_execute($stid);

$row = oci_fetch_assoc($stid);

if ($row) {
    // Verify password
    if (password_verify($password, $row['PASSWORD'])) {
        echo "Login successful!";
        // later → redirect to dashboard
    } else {
        echo "Invalid password!";
    }
} else {
    echo "User not found!";
}
?>
