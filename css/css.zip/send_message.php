<?php
session_start();
if (!isset($_SESSION['person_id'])) {
    header('Location: ../login.php');
    exit();
}
require_once '../includes/db_connect.php';
if (!isset($_SESSION['lang'])) $_SESSION['lang'] = 'en';
require_once "../includes/lang_{$_SESSION['lang']}.php";

$person_id = $_SESSION['person_id'];

$sql = "SELECT request_id, title FROM request
        WHERE requester_person_id = ? OR assignee_person_id = ?
        ORDER BY created_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $person_id, $person_id);
$stmt->execute();
$requests = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$sql2 = "SELECT person_id, first_name, last_name FROM person WHERE person_id != ? ORDER BY last_name";
$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("i", $person_id);
$stmt2->execute();
$persons = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/index.css">
    <title><?= $lang['send_message'] ?></title>
</head>
<body>
    <div class="container">
        <p style="text-align:right;">
            <a href="../switch_lang.php?lang=en">English</a> | 
            <a href="../switch_lang.php?lang=tr">Türkçe</a>
        </p>
        <h2><?= $lang['send_message'] ?></h2>
        <form action="Proces/message_process.php" method="POST">
            <label><?= $lang['to'] ?>:</label>
            <select name="receiver_id" required>
                <option value=""><?= $lang['select_recipient'] ?></option>
                <?php foreach ($persons as $p): ?>
                    <option value="<?= $p['person_id'] ?>">
                        <?= $p['first_name'] . ' ' . $p['last_name'] ?></option>
                <?php endforeach; ?>
            </select><br><br>

            <label><?= $lang['subject'] ?> (opsiyonel):</label>
            <input type="text" name="subject"><br><br>

            <label><?= $lang['body'] ?>:</label>
            <textarea name="body" required></textarea><br><br>

            <label><?= $lang['related_request'] ?>:</label>
            <select name="request_id" required>
                <option value=""><?= $lang['select_request'] ?></option>
                <?php foreach ($requests as $req): ?>
                    <option value="<?= $req['request_id'] ?>">
                        <?= htmlspecialchars($req['title']) ?></option>
                <?php endforeach; ?>
            </select><br><br>

            <button type="submit"><?= $lang['send'] ?></button>
        </form>
    </div>
</body>
</html>
            