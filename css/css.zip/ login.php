<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="..css/index.css">
    <script src="../js/index.js"></script>
</head>
<body>

<h2>Login</h2>

<form action="login_process.php" method="POST">
    Email: <input type="text" name="email" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    
    <button type="submit">Login</button>
</form>

</body>
</html>
