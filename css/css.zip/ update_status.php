<?php
session_start();
include "../includes/db.php";

$id = $_POST['id'];
$status = $_POST['status'];

/* Update request status */
$sql = "UPDATE demande 
        SET status = :status 
        WHERE id = :id";

$stid = oci_parse($conn, $sql);

oci_bind_by_name($stid, ":status", $status);
oci_bind_by_name($stid, ":id", $id);

if (oci_execute($stid)) {

    /* Get request owner */
    $query = "SELECT user_id FROM demande WHERE id = :id";

    $qstid = oci_parse($conn, $query);
    oci_bind_by_name($qstid, ":id", $id);
    oci_execute($qstid);

    $row = oci_fetch_assoc($qstid);

    $user_id = $row['USER_ID'];

    /* Create notification */
    $message = "Your request status changed to: " . $status;

    $notif_sql = "INSERT INTO notification (user_id, message)
                  VALUES (:user_id, :message)";

    $notif_stid = oci_parse($conn, $notif_sql);

    oci_bind_by_name($notif_stid, ":user_id", $user_id);
    oci_bind_by_name($notif_stid, ":message", $message);

    oci_execute($notif_stid);

    header("Location: admin_dashboard.php");

} else {
    echo "Error updating status!";
}
?>
